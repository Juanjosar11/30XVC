import './framer/styles.css'

import SpeakerCardsFramerComponent from './framer/speaker-cards'
import SponsorCardFramerComponent from './framer/sponsor-card'
import AccordionsFramerComponent from './framer/accordions'
import SectionTagFramerComponent from './framer/section-tag'
import DayTitleFramerComponent from './framer/day-title'
import WhomCardFramerComponent from './framer/whom-card'
import TicketCardsFramerComponent from './framer/ticket-cards'
import CircleArrowFramerComponent from './framer/circle-arrow'
import RightArrowFramerComponent from './framer/right-arrow'
import GuestCardFramerComponent from './framer/guest-card'

export default function App() {
  return (
    <div className='flex flex-col items-center gap-3 bg-[rgb(255,_255,_255)]'>
      <SpeakerCardsFramerComponent.Responsive
        ZnwXRPx3Z={"Dr. Emma Parker"}
        nIvBNoSTH={"Chief AI Scientist"}
        tM8THrjkl={"https://www.instagram.com/jitu.ux/"}
        tyhjRkC9z={"www.linkedin.com/in/jitendra-raut/"}
      />
      <SponsorCardFramerComponent.Responsive/>
      <AccordionsFramerComponent.Responsive/>
      <SectionTagFramerComponent.Responsive
        nx4Vg5CG3={"rgb(255, 255, 255)"}
        zbD88MwBd={"For Whom?"}
      />
      <DayTitleFramerComponent.Responsive
        Usf4fiXwj={"Day 1 : Main Conference"}
        sB9Iwdbsx={"Kickoff"}
      />
      <WhomCardFramerComponent.Responsive
        AOzSz5R2Y={"Explore powerful new frameworks, join immersive technical sessions, solve real-world problems with AI, and grow within a thriving dev community."}
        DICEOonaS={"Identify breakthrough innovations, connect with disruptive startups, gain deep insights into AI trends, and uncover your next big opportunity."}
        EfD_tVDRE={"Unlock AI’s potential to optimize operations, enhance customer experiences, drive data-informed decisions, and stay competitive in a fast-evolving market."}
        HrCFO37Cw={"Learn how to build smarter products, scale faster with AI-driven tools, refine your strategy with expert guidance, and meet future collaborators or backers."}
      />
      <TicketCardsFramerComponent.Responsive/>
      <CircleArrowFramerComponent.Responsive/>
      <RightArrowFramerComponent.Responsive
        dgxltENRQ={"rgb(0, 0, 0)"}
        f18APUT6o={"rgb(255, 255, 255)"}
        m7JWepczT={"/speakers"}
      />
      <GuestCardFramerComponent.Responsive
        QmtD_b0ER={"John Mitchell"}
        XkNCZnR0o={"Co-Founder at AI Corp"}
      />
    </div>
  );
};